from flask import Flask, render_template, request
import requests

app = Flask(__name__)

GOOGLE_FACTCHECK_API_KEY = "AIzaSyDqAE8V2gQZMvpzm3KJ-v2KAgnPFNhNE3I"

def fact_check_with_google(claim):
    try:
        url = f"https://factchecktools.googleapis.com/v1alpha1/claims:search?query={claim}&key={GOOGLE_FACTCHECK_API_KEY}"
        response = requests.get(url)
        data = response.json()

        if "claims" in data and len(data["claims"]) > 0:
            first_claim = data["claims"][0]
            text = first_claim.get("text", "No claim text.")
            rating = first_claim["claimReview"][0].get("textualRating", "Unrated")
            url = first_claim["claimReview"][0].get("url", "#")
            publisher = first_claim["claimReview"][0].get("publisher", {}).get("name", "Unknown Source")

            return f"✅ Real News! Verified by {publisher} — {rating}\n\n🔗 Source: {url}"
        else:
            return "❌ Try again. Couldn't verify this claim with any source."

    except Exception as e:
        return f"Error verifying news: {e}"

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        news = request.form.get("news", "")
        if news.strip():
            result = fact_check_with_google(news)
        else:
            result = "Please enter a news statement."
    return render_template("index.html", result=result, request=request)

if __name__ == "__main__":
    app.run(debug=True)
